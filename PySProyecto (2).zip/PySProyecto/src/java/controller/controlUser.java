/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.PySDAO;
import java.io.File;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import model.Practicas;
import java.util.*;
import javax.servlet.http.Part;
import model.SolicitudesP;

@WebServlet(name = "controlUser", urlPatterns = {"/controlUser"})
public class controlUser extends HttpServlet {

    
    private PySDAO data;
    
    public controlUser(){
        super();
        data = new PySDAO();
    }
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //el metodo GET recibe todas las llamadas no especificadas en el JSP/HTML como POST 
        String forward="";//almacena la ruta a la que debe redireccionar al usuario
        String action = request.getParameter("action");
        
         if (action.equalsIgnoreCase("consultaUserInsP")) {
            request.getSession().setAttribute("tipoUser", "User");
            request.getSession().setAttribute("modalidad", "Practicas");

            forward = "/PyS/Instituciones.jsp";
            this.redireccionar(forward, request, response);
            
        } else if (action.equalsIgnoreCase("consultaUserInsS")) {
            request.getSession().setAttribute("tipoUser", "User");
            request.getSession().setAttribute("modalidad", "Servicio");
            
            forward = "/PyS/Instituciones.jsp";
            this.redireccionar(forward, request, response);
            
        }else if (action.equalsIgnoreCase("procesoPracticas")) {
            int mat = Integer.parseInt(request.getParameter("matricula"));
            request.getSession().setAttribute("proceso", data.validarUserSolicitudP(mat));
            
            forward = "/PyS/users/practicas/practicasUser.jsp";
            this.redireccionar(forward, request, response);
            
        }else if (action.equalsIgnoreCase("solicitudIP")) {
            int mat = Integer.parseInt(request.getParameter("matricula"));
            request.getSession().setAttribute("P", data.validarUserSolicitudP(mat));
            request.getSession().setAttribute("D", data.listInsP());
            

            forward = "/PyS/users/practicas/solicitudUser.jsp";
            this.redireccionar(forward, request, response);
            
        }else if (action.equalsIgnoreCase("validarDatosP")) {
            int mat = Integer.parseInt(request.getParameter("matricula"));
            request.getSession().setAttribute("validarSolicitud", data.validarUserSolicitudP(mat));
            request.getSession().setAttribute("P", data.validarDatosUserP(mat));

            forward = "PyS/users/practicas/validarDatos.jsp";
            this.redireccionar(forward, request, response);
            
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {            
        
        String forward="";//almacena la ruta a la que debe redireccionar al usuario
        String action = request.getParameter("action");//obtiene el valor del campo 'action' del JSP
        response.setContentType("text/plain; charset=UTF-8");//establece el tipo de contenido de la respuesta 'text' en unicode UTF8
        PrintWriter out = response.getWriter();
        
        if (action.equalsIgnoreCase("solicitudUserP")) {
            
            int matricula = Integer.parseInt(request.getParameter("matricula"));
            int id_institucion = Integer.parseInt(request.getParameter("institucion"));
            String turno = request.getParameter("turno");   
                      
            data.solicitudesP(matricula, id_institucion);
            data.esperaPracticas(matricula, id_institucion, turno);
            
            forward = "/PyS/users/solicitudUser.jsp";
            this.redireccionar(forward, request, response);
            
        }/*else if (action.equalsIgnoreCase("subirDocumentosP")) {
            
            int FolioP;
            FolioP = Integer.parseInt(request.getParameter("folio"));
            
            //obtener la ruta absoluta de la AppWeb
            String appPath = request.getServletContext().getRealPath("");
            //construir la ruta donde se almacenara el archivo
            String savePath = appPath + File.separator + SAVE_DIR;               
            
            /****** crear el directorio images en caso de que no exista *******/
        /*
            File fileSaveDir = new File(savePath);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdir();
            }
            //fusionar el nombre de la carpeta + nombre-archivo
            String nombreArchivo = SAVE_DIR + "/" + fileNameUploaded;
            data.subirDocumentosFinalesP(FolioP, nombreArchivo);
        
            request.setAttribute("message", "Upload has been done successfully!  " + savePath + "/" +fileNameUploaded);
            getServletContext().getRequestDispatcher("/messageUpload.jsp").forward(
                request, response);  
            forward = "PyS/users/practicas/subirDocumentos.jsp";
            this.redireccionar(forward, request, response);
     
        }*/
    }

    /*** metodo que extrae el nombre del archivo del header HTTP content-disposition ***/
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
    
    public void redireccionar(String forward,HttpServletRequest request,HttpServletResponse response) 
            throws ServletException, IOException{
        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
    }    
    
}
