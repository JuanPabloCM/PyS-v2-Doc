package DAO;

import java.sql.*;
import java.util.*;
import model.*;
import util.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class FileDAO {
    private Connection connection;
     //un metodo constructor no regresa ningun tipo de dato e inicializa el objeto 
    public FileDAO()
    {
        connection=DataBase.getConnection();       
    }//fin del constructor
    
    public void subirDocumentosFinalesP(String archivo) 
    {
     try{        
        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO DocumentosFinalesP VALUES (0,8,?,now(),0)");
        preparedStatement.setString(1, archivo);
        preparedStatement.executeUpdate();
     }catch(SQLException e){
        e.printStackTrace();
     }  
    }
    
    public void subirDocumentosP(int FolioP, String archivo, String archivo2, String archivo3) 
    {
     try{        
        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO DocumentosP VALUES (0,?,?,?,?,now()");
        preparedStatement.setInt(1, FolioP);
        preparedStatement.setString(2, archivo);
        preparedStatement.setString(2, archivo2);
        preparedStatement.setString(3, archivo3);
        preparedStatement.executeUpdate();
     }catch(SQLException e){
        e.printStackTrace();
     }  
    }
    
}
