package DAO;

import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Institucion;
import model.Persona;
import model.Practicas;
import model.Servicio;
import model.SolicitudesP;
import util.DataBase;

        
public class PySDAO {
    /************************************************************
    * Atributos de la clase
    ************************************************************/
    private Connection con=null;//variable para la conexion a la BD
    /************************************************************
    * Metodos constructores
    *************************************************************/
    public PySDAO()
    {
        con = DataBase.getConnection();//crear una conexión al crear un objeto PySDAO
    }
    //Metodos/funciones de la clase
    /************************************************************
    * Metodo que para dar de alta una institucion
    * para practicas y servicio
    ************************************************************/
    /*public void AltaInstitucion(String Nombre_Institucion, String Nombre_Proyecto, String Nombre_Encargado, String Cargo_Encargado, String Telefono_Encargado, String Email_Encargado, boolean Practicas_Servicio, boolean Apoyo_Economico, int Monto, int Vacantes, String Horario)
    {
       
        try{
            
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "insert into Institucion (Nombre_Institucion, Nombre_Proyecto, Nombre_Encargado, Cargo_Encargado, Telefono_Encargado, Email_Encargado, Practicas_Servicio, Apoyo_Economico, Monto, Vacantes, Horario) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            //pstm.setInt(1, 0);
            pstm.setString(1, Nombre_Institucion);
            pstm.setString(2, Nombre_Proyecto);
            pstm.setString(3, Nombre_Encargado);
            pstm.setString(4, Cargo_Encargado);
            pstm.setString(5, Telefono_Encargado);
            pstm.setString(6, Email_Encargado);
            pstm.setBoolean(7, Practicas_Servicio);
            pstm.setBoolean(8, Apoyo_Economico);
            pstm.setInt(9, Monto);
            pstm.setInt(10, Vacantes);
            pstm.setString(11, Horario);
            pstm.executeUpdate();
            con.close();
        } catch (SQLException e) {          
        }
    }*/
    public void subirDocumentosFinalesP(int FolioP, String archivo) 
    {
     try{        
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO DocumentosP VALUES (0,?,?,now(),0");
        preparedStatement.setInt(1, FolioP);
        preparedStatement.setString(2, archivo);
        preparedStatement.executeUpdate();
     }catch(SQLException e){
        e.printStackTrace();
     }  
    }
    
    public void subirDocumentosP(int FolioP, String archivo, String archivo2, String archivo3) 
    {
     try{        
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO DocumentosP VALUES (0,?,?,?,?,now()");
        preparedStatement.setInt(1, FolioP);
        preparedStatement.setString(2, archivo);
        preparedStatement.setString(2, archivo2);
        preparedStatement.setString(3, archivo3);
        preparedStatement.executeUpdate();
     }catch(SQLException e){
        e.printStackTrace();
     }  
    }
    
    public Practicas obtenerFolioP(int matricula){
        Practicas datos = new Practicas();
        try{
            PreparedStatement ps = con.prepareStatement("select FolioP from Practicas where matricula = ?");
            ps.setInt(1, matricula);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                datos.setFolioP(rs.getInt("FolioP"));
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public Institucion nombreInstitucion(int I){
        Institucion datos = new Institucion();
        try{
            PreparedStatement ps = con.prepareStatement("select Nombre_Institucion from Institucion where ID_Institucion = ?");
            ps.setInt(1, I);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                datos.setNombre_Institucion(rs.getString("Nombre_Institucion"));
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public SolicitudesP validarDatosUserP(int matricula){
        SolicitudesP datos = new SolicitudesP();
        try{
            PreparedStatement ps = con.prepareStatement("select ID_SolicitudP, Matricula , ID_Institucion from SolicitudesP where matricula = ?");
            ps.setInt(1, matricula);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                datos.setID_SolicitudP(rs.getInt("ID_SolicitudP"));
                datos.setMatricula(rs.getInt("Matricula"));
                datos.setID_Institucion(rs.getInt("ID_Institucion"));
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public SolicitudesP validarUserSolicitudP(int matricula){
        SolicitudesP datos = new SolicitudesP();
        try{
            PreparedStatement ps = con.prepareStatement("select ID_SolicitudP, ActivaA, ActivaI from SolicitudesP where matricula = ?");
            ps.setInt(1, matricula);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                datos.setID_SolicitudP(rs.getInt("ID_SolicitudP"));
                datos.setActivaA(rs.getBoolean("ActivaA"));
                datos.setActivaI(rs.getBoolean("ActivaI"));
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public void esperaPracticas(int matricula, int institucion, String turno){
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "insert into Practicas values (0,?,?,500,?,0,0)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, matricula);
            pstm.setInt(2, institucion);
            pstm.setString(3, turno);
            pstm.executeUpdate();
            con.close();
        }catch (SQLException e) { 
            e.printStackTrace();
        }
    }
    
    public void esperaServicio(int matricula, int institucion, String modalidad, String turno){
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "insert into Servicio values (0,?,?,500,?,?,0,0)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, matricula);
            pstm.setInt(2, institucion);
            pstm.setString(3, modalidad);
            pstm.setString(4, turno);
            pstm.executeUpdate();
            con.close();
        }catch(SQLException e) { 
            e.printStackTrace();
        }
    }
    
    public boolean solicitudesS(int matricula, int institucion){
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "insert into SolicitudesS values (0,?,?,0)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, matricula);
            pstm.setInt(2, institucion);
            if (pstm.executeUpdate() == 1)
            {
                return true;
            }
        }catch (SQLException e) { 
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean solicitudesP(int matricula, int institucion){
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "insert into SolicitudesP values (0,?,?,now(),0,1)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, matricula);
            pstm.setInt(2, institucion);
            if (pstm.executeUpdate() == 1)
            {
                return true;
            }
        }catch (SQLException e) { 
            e.printStackTrace();
        }
        return false;
    }
    
    public List<Institucion> listInsP(){
        List<Institucion> datos = new ArrayList();
        try{
            PreparedStatement ps = con.prepareStatement("select ID_Institucion, Nombre_Institucion from Institucion where Practicas_Servicio = 0");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Institucion I = new Institucion();
                I.setID_Institucion(rs.getInt("ID_Institucion"));
                I.setNombre_Institucion(rs.getString("Nombre_Institucion"));
                datos.add(I);
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public List<Institucion> listInsS(){
        List<Institucion> datos = new ArrayList();
        try{
            PreparedStatement ps = con.prepareStatement("select ID_Institucion, Nombre_Institucion from Institucion where Practicas_Servicio = 1");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Institucion I = new Institucion();
                I.setID_Institucion(rs.getInt("ID_Institucion"));
                I.setNombre_Institucion(rs.getString("Nombre_Institucion"));
                datos.add(I);
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public List<Institucion> listIns(){
        List<Institucion> datos = new ArrayList();
        try{
            PreparedStatement ps = con.prepareStatement("select ID_Institucion, Nombre_Institucion from Institucion");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Institucion I = new Institucion();
                I.setID_Institucion(rs.getInt("ID_Institucion"));
                I.setNombre_Institucion(rs.getString("Nombre_Institucion"));
                datos.add(I);
            } 
        } catch (SQLException ex){
                    ex.printStackTrace();
                    }
        return datos;
    }
    
    public List<Institucion> consultarInsServicio(){
        List<Institucion> datos = new ArrayList();
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "select Nombre_Institucion, Nombre_Proyecto, Nombre_Encargado, Cargo_Encargado, Telefono_Encargado, Email_Encargado, Apoyo_Economico, Monto, Vacantes, Horario from Institucion WHERE Practicas_Servicio = 1";
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            while(rs.next()){
                Institucion I = new Institucion();
                I.setNombre_Institucion(rs.getString("Nombre_Institucion"));
                I.setNombre_Proyecto(rs.getString("Nombre_Proyecto"));
                I.setNombre_Encargado(rs.getString("Nombre_Encargado"));
                I.setCargo_Encargado(rs.getString("Cargo_Encargado"));
                I.setTelefono_Encargado(rs.getString("Telefono_Encargado"));
                I.setEmail_Encargado(rs.getString("Email_Encargado"));
                I.setApoyo_Economico(rs.getBoolean("Apoyo_Economico"));
                I.setMonto(rs.getInt("Monto"));
                I.setVacantes(rs.getInt("Vacantes"));
                I.setHorario(rs.getString("Horario"));
                datos.add(I);
            } 
            con.close();
        } catch (SQLException e) {
            
        }
        return datos;
    }
    
    public List<Institucion> consultarInsPracticas(){
        List<Institucion> datos = new ArrayList();
        try{
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String sql = "select Nombre_Institucion, Nombre_Proyecto, Nombre_Encargado, Cargo_Encargado, Telefono_Encargado, Email_Encargado, Apoyo_Economico, Monto, Vacantes, Horario from Institucion";
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            while(rs.next()){
                Institucion I = new Institucion();
                I.setNombre_Institucion(rs.getString("Nombre_Institucion"));
                I.setNombre_Proyecto(rs.getString("Nombre_Proyecto"));
                I.setNombre_Encargado(rs.getString("Nombre_Encargado"));
                I.setCargo_Encargado(rs.getString("Cargo_Encargado"));
                I.setTelefono_Encargado(rs.getString("Telefono_Encargado"));
                I.setEmail_Encargado(rs.getString("Email_Encargado"));
                I.setApoyo_Economico(rs.getBoolean("Apoyo_Economico"));
                I.setMonto(rs.getInt("Monto"));
                I.setVacantes(rs.getInt("Vacantes"));
                I.setHorario(rs.getString("Horario"));
                datos.add(I);
            } 
            con.close();
        } catch (SQLException e) {
            
        }
        return datos;
    }
    
    public List<Institucion> consultar(){
        List<Institucion> datos = new ArrayList();
        PreparedStatement pstm = null; 
        ResultSet rs = null;
        String sql = "select * from Institucion";
        try{
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            while(rs.next()){
                datos.add(new Institucion(rs.getInt("ID_Institucion"), rs.getString("Nombre_Institucion"), rs.getString("Nombre_Proyecto"), rs.getString("Nombre_Encargado"), rs.getString("Cargo_Encargado"), rs.getString("Telefono_Encargado"), rs.getString("Email_Encargado"), rs.getBoolean("Practicas_Servicio"), rs.getBoolean("Apoyo_Economico"), rs.getInt("Monto"), rs.getInt("Vacantes"), rs.getString("Horario")));
            }
            con.close();
        } catch (SQLException e) {
            
        }
        return datos;
    }
    
    public int obtenerIdPersona(int id){
        int id_persona = 0;
        try 
        {
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String query = "SELECT ID_Persona FROM persona WHERE ID_User = ?";
            pstm = con.prepareStatement(query);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            if(rs.next())
            {                
                id_persona = rs.getInt("ID_Persona");
            }
        }catch(Exception ex)
        {
            ex.printStackTrace();                
        }            
        return id_persona;
    }
    
    public int obtenerMatricula(int id_persona){
        int matricula = 0;
        try 
        {
            PreparedStatement pstm = null; 
            ResultSet rs = null;
            String query = "SELECT Matricula FROM alumno WHERE ID_Persona = ?";
            pstm = con.prepareStatement(query);
            pstm.setInt(1, id_persona);
            rs = pstm.executeQuery();
            if(rs.next())
            {                
                matricula = rs.getInt("Matricula");
            }
        }catch(Exception ex)
        {
            ex.printStackTrace();                
        }            
        return matricula;
    }
    
    /*public static void main(String[] args) {
        PySDAO I = new PySDAO();
        Institucion Ins = new Institucion();
        Ins.setNombre_Institucion("Lol");
        Ins.setNombre_Proyecto("Lol");
        Ins.setNombre_Encargado("Lol");
        Ins.setCargo_Encargado("Lol");
        Ins.setTelefono_Encargado("666");
        Ins.setEmail_Encargado("Lol");
        Ins.setPracticas_Servicio(true);
        Ins.setApoyo_Economico(false);
        Ins.setMonto(300);
        Ins.setVacantes(2);
        Ins.setHorario("lol");
        I.AltaInstitucion(Ins);
    }*/
}
