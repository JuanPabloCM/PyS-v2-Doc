/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class SolicitudesP {
    //atributos de la clase
    private int ID_SolicitudP, Matricula, ID_Institucion;
    private boolean ActivaA, ActivaI;
    private String date;
    
    //contructor
    public SolicitudesP(){}

    public int getID_SolicitudP() {
        return ID_SolicitudP;
    }

    public void setID_SolicitudP(int ID_SolicitudP) {
        this.ID_SolicitudP = ID_SolicitudP;
    }

    public int getMatricula() {
        return Matricula;
    }

    public void setMatricula(int Matricula) {
        this.Matricula = Matricula;
    }

    public int getID_Institucion() {
        return ID_Institucion;
    }

    public void setID_Institucion(int ID_Institucion) {
        this.ID_Institucion = ID_Institucion;
    }

    public boolean isActivaA() {
        return ActivaA;
    }

    public void setActivaA(boolean ActivaA) {
        this.ActivaA = ActivaA;
    }

    public boolean isActivaI() {
        return ActivaI;
    }

    public void setActivaI(boolean ActivaI) {
        this.ActivaI = ActivaI;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    
    
    
}
