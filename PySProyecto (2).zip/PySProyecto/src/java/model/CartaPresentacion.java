package model;

public class CartaPresentacion {

    //Atributos
    private int ID_CartaPresentacion, FolioP;
    private String Documento, date;
    private boolean Activa;
    
    public CartaPresentacion() {
    }

    public int getID_CartaPresentacion() {
        return ID_CartaPresentacion;
    }

    public void setID_CartaPresentacion(int ID_CartaPresentacion) {
        this.ID_CartaPresentacion = ID_CartaPresentacion;
    }

    public int getFolioP() {
        return FolioP;
    }

    public void setFolioP(int FolioP) {
        this.FolioP = FolioP;
    }

    public String getDocumento() {
        return Documento;
    }

    public void setDocumento(String Documento) {
        this.Documento = Documento;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isActiva() {
        return Activa;
    }

    public void setActiva(boolean Activa) {
        this.Activa = Activa;
    }
    
    
}
