package model;
    /************************************************************
    * Datos de la tabla SolocitudS
    ************************************************************/
public class SolicitudesS {
    //atributos de la clase
    private int ID_SolicitudS, Matricula, ID_Institucion;
    private boolean ActivaA, ActivaI;
    private String date;
    
    //contructor
    public SolicitudesS(){}

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    public int getID_SolicitudS() {
        return ID_SolicitudS;
    }

    public void setID_SolicitudS(int ID_SolicitudS) {
        this.ID_SolicitudS = ID_SolicitudS;
    }

    public int getMatricula() {
        return Matricula;
    }

    public void setMatricula(int Matricula) {
        this.Matricula = Matricula;
    }

    public int getID_Institucion() {
        return ID_Institucion;
    }

    public void setID_Institucion(int ID_Institucion) {
        this.ID_Institucion = ID_Institucion;
    }

    public boolean isActivaA() {
        return ActivaA;
    }

    public void setActivaA(boolean ActivaA) {
        this.ActivaA = ActivaA;
    }

    public boolean isActivaI() {
        return ActivaI;
    }

    public void setActivaI(boolean ActivaI) {
        this.ActivaI = ActivaI;
    }

    
    
}
