package model;

public class DocumentosFinalesP {
  
    //Atributos
    private int ID_DocumentosFinalesP, FolioP;
    private String Documento, date;
    private boolean Activa;  

    public DocumentosFinalesP() {
    }

    public int getID_DocumentosFinalesP() {
        return ID_DocumentosFinalesP;
    }

    public void setID_DocumentosFinalesP(int ID_DocumentosFinalesP) {
        this.ID_DocumentosFinalesP = ID_DocumentosFinalesP;
    }

    public int getFolioP() {
        return FolioP;
    }

    public void setFolioP(int FolioP) {
        this.FolioP = FolioP;
    }

    public String getDocumento() {
        return Documento;
    }

    public void setDocumento(String Documento) {
        this.Documento = Documento;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isActiva() {
        return Activa;
    }

    public void setActiva(boolean Activa) {
        this.Activa = Activa;
    }

    
}
