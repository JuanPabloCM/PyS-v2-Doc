package model;

public class DocumentosP {
    
    //Atributos
    private int ID_DocumentosP, FolioP;
    private String Documento, date;
    private boolean Activa; 

    public DocumentosP() {
    }

    public int getID_DocumentosP() {
        return ID_DocumentosP;
    }

    public void setID_DocumentosP(int ID_DocumentosP) {
        this.ID_DocumentosP = ID_DocumentosP;
    }

    public int getFolioP() {
        return FolioP;
    }

    public void setFolioP(int FolioP) {
        this.FolioP = FolioP;
    }

    public String getDocumento() {
        return Documento;
    }

    public void setDocumento(String Documento) {
        this.Documento = Documento;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isActiva() {
        return Activa;
    }

    public void setActiva(boolean Activa) {
        this.Activa = Activa;
    }
    
    
}
